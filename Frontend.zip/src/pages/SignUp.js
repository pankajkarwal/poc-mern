import React,{useState} from 'react'

import axios from 'axios';
import styles from './Signup.module.css';
import Group from "../images/Group-938.svg"
import Group512 from "../images/Group-512.svg"
import Group471 from "../images/Group-471.svg"
import Vector from "../images/Vector.svg"
import Email from "../images/email-1.svg"
import Privacy from "../images/privacy-1.svg"
import Hide from "../images/hide-2.svg"

const SignUp = () => {
  const [first_name,setFName] = useState();
  const [last_name,setLName] = useState();
  const [mobile,setMobile] = useState();
  const [email,setEmail] = useState();
  const [city,setCity] = useState();
  const [password,setPassword] = useState();
  const submitData =(e) => {
    e.preventDefault();
    const data ={
      first_name,
      last_name,
      mobile,
      email,password,city
    }
   // Call user add api
    axios.post('http://localhost:5002/user/add',data).then((res) => {
      console.log("Submitted");
      window.location.replace('/add');
    }).catch((err)=>{
      console.log("Error",err);
    })
    
  }
  	return (
    		<div className={styles.signUp}>
      			<div className={styles.signUpChild} />
      			<div className={styles.signUpWrapper}>
        				<b className={styles.signUp1}>Sign Up</b>
      			</div>
      			<img className={styles.signUpItem} alt="" src={Group} />
      			<div className={styles.signUpInner}>
        				<div className={styles.firstNameParent}>
          					<div className={styles.firstName}>First Name</div>
          					<div className={styles.groupChild} />
          					<div className={styles.groupItem} />
          					<div className={styles.robertParent}>
            						
                        <input className={styles.robert} onChange={(e) => setFName(e.target.value)} value={first_name} />
            						<img className={styles.groupInner} alt="" src={Group512} />
          					</div>
        				</div>
      			</div>
      			<div className={styles.groupDiv}>
        				<div className={styles.firstNameParent}>
          					<div className={styles.firstName}>Last Name</div>
          					<div className={styles.groupChild} />
          					<div className={styles.groupItem} />
          					<div className={styles.downeyJrParent}>
            						<div className={styles.downeyJr}>
                        <input  onChange={(e) => setLName(e.target.value)} value={last_name} />
            					
                        </div>
            						<img className={styles.groupChild2} alt="" src={Group512} />
          					</div>
        				</div>
      			</div>
      			<div className={styles.mobileNoParent}>
        				<div className={styles.mobileNo}>Mobile No.</div>
        				<div className={styles.groupChild3} />
        				<div className={styles.div}>
                <input  onChange={(e) => setMobile(e.target.value)} value={mobile} />
            				
                </div>
        				<img className={styles.groupChild4} alt="" src={Group471}/>
        				<div className={styles.parent}>
          					<div className={styles.div1}>+91</div>
                   	
          					<img className={styles.vectorIcon1} alt="" src={Vector} />
        				</div>
        				<div className={styles.groupChild5} />
      			</div>
      			<div className={styles.rdjgmailcomParent}>
        				<div className={styles.rdjgmailcom}><input  onChange={(e) => setEmail(e.target.value)} value={email} />
            			</div>
        				<img className={styles.email1Icon1} alt="" src={Email} />
        				<div className={styles.groupChild6} />
        				<div className={styles.groupChild7} />
        				<div className={styles.emailId}>
                		
                </div>
      			</div>
      			<div className={styles.cityParent}>
        				<div className={styles.firstName}>City</div>
        				<div className={styles.groupChild8} />
        				<div className={styles.pune}>
                <input  onChange={(e) => setCity(e.target.value)} value={city} />
            					
                </div>
      			</div>
      			<div className={styles.enterPasswordParent}>
        				<div className={styles.firstName}>Enter Password</div>
        				<div className={styles.groupChild} />
        				<div className={styles.groupItem} />
        				<div className={styles.div2}>
                <input  onChange={(e) => setPassword(e.target.value)} value={password} />
            					
                </div>
        				<img className={styles.privacy1Icon1} alt="" src={Privacy}/>
        				<img className={styles.hide2Icon1} alt="" src={Hide} />
      			</div>
      			<div className={styles.rectangleParent}>
        				<div className={styles.rectangleDiv} />
        				<a onClick={(e) =>submitData(e)} className={styles.submit}>Submit</a>
      			</div>
    		</div>);
};

export default SignUp;
