import { FileUploader } from "react-drag-drop-files";

import styles from './AddNewMoment.module.css';
import React, { useState } from 'react'
import axios from 'axios';
import Group504 from "../images/Group-504.png"
import Group512 from "../images/Group-512.svg"
import Group471 from "../images/Group-471.svg"
import Vector from "../images/Vector.svg"
import logo from "../images/5d-light-1.svg"
import Privacy from "../images/privacy-1.svg"
import upload from "../images/upload-1.svg"

const AddNewMoment = () => {
  const [title, setTitle] = useState('')
  const [tag, setTag] = useState('')
  const [fileName, setFileName] = useState(null)

  const submitData = (e) => {
    e.preventDefault();
    const formdata = new FormData()
    formdata.append("title", title)
    formdata.append("tag", tag)
    formdata.append("fileName", fileName)

    const data = {
      title,
      tag,
      fileName
    }
    console.log(data)
    // Call user add api
    axios.post('http://localhost:5002/moment/add', data,
    {
      headers:{'Content-Type':'multipart/form-data'}
    }).then((res) => {
      console.log("Submitted");
    }).catch((err) => {
      console.log("Error", err);
    })

  }

  const fileTypes = ["JPEG", "PNG", "GIF"];
  const handleChange = (file) => {
    setFileName(file[0]);
  };
  return (
    <div className={styles.addNewMoment3}>
      <form encType="multipart/form-data" >
        <div className={styles.addNewMomentChild} />
        <div className={styles.addNewMomentItem} />
        <img className={styles.addNewMomentInner} alt="" src="Ellipse 141.png" />
        <img className={styles.addNewMomentChild1} alt="" src={Group504} />
        <div className={styles.rectangleDiv} />
        <b className={styles.addNewMoment4}>Add new moment</b>
        <img className={styles.arrowDownSignToNavigate1Icon1} alt="" src="arrow-down-sign-to-navigate 1.svg" />
        <div className={styles.profile}>Profile</div>
        <div className={styles.momentList}>Moment List</div>
        <div className={styles.addNewMomentParent}>
          <div className={styles.addNewMoment5}>Add new moment</div>
          <div className={styles.groupChild} />
        </div>
        <div className={styles.rectangleParent}>
          <div className={styles.groupItem} />
          <div className={styles.momentsParent}>
            <b className={styles.moments}>Moments</b>
            <img className={styles.vectorIcon2} alt="" src={Vector} />
          </div>
        </div>
        <img className={styles.dLight11} alt="" src={logo} />
        <div className={styles.addNewMomentChild2} />
        <div className={styles.titleParent}>
          <div className={styles.title}>Title</div>
          <div className={styles.groupInner} />
          <div className={styles.sampleTitle}>
            <input onChange={(e) => setTitle(e.target.value)} value={title} />

          </div>
        </div>
        <div className={styles.tags}>Tags</div>


        
        <div className={styles.upload1Parent}>

          <FileUploader
            multiple={true}
            handleChange={handleChange}
            name="fileName"
            types={fileTypes}
          />
        </div>
        <div className={styles.rectangleContainer}>
          
        </div>
        <div className={styles.groupDiv}>
        </div>
        <img className={styles.groupIcon3} alt="" src="Group.svg" />
        <img className={styles.groupIcon4} alt="" src="Group.svg" />
        <img className={styles.googleDocs1Icon1} alt="" src="google-docs 1.svg" />
        <div className={styles.rectangleParent1}>
          <div className={styles.groupChild6} />
          <a className={styles.submit} onClick={(e) => submitData(e)}>Submit</a>
        </div>
        <div className={styles.rectangleParent2}>
          <div className={styles.groupChild7} />
          <div className={styles.groupParent}>
            <div className={styles.rectangleParent3}>
              <div className={styles.groupChild8} />
              <img className={styles.vectorIcon3} alt="" src={Vector} />
            </div>
            <div className={styles.moments}> <input onChange={(e) => setTag(e.target.value)} value={tag} /></div>
          </div>
        </div>
      </form>
    </div>);
};

export default AddNewMoment;
